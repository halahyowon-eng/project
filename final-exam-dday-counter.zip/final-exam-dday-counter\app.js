/**
 * Final Exam D-Day Tracker - Core Logic & Controller
 */

// 1. Data Structures & Initialization
let ExamList = [];

// Demo data if localStorage is empty
const defaultExams = [
  {
    id: "demo-1",
    course: "사회학이론",
    date: "2026-06-23T14:00",
    priority: "상"
  },
  {
    id: "demo-2",
    course: "컴퓨터프로그래밍",
    date: "2026-06-27T10:00",
    priority: "상"
  },
  {
    id: "demo-3",
    course: "경제학원론",
    date: "2026-06-20T09:00",
    priority: "중"
  }
];

// Load data from LocalStorage
function loadExams() {
  const stored = localStorage.getItem("ExamList");
  if (stored) {
    try {
      ExamList = JSON.parse(stored);
    } catch (e) {
      console.error("Error parsing stored exam list", e);
      ExamList = [...defaultExams];
    }
  } else {
    // Set initial demo exams
    ExamList = [...defaultExams];
    saveExams();
  }
}

// Save data to LocalStorage
function saveExams() {
  localStorage.setItem("ExamList", JSON.stringify(ExamList));
}

// Get Current Date in KST (Time Zone offset helper if needed, or local system time)
function getCurrentDate() {
  return new Date();
}

// 2. D-Day Real-Time Calculation Algorithm
function calculateAllDDays() {
  const today = getCurrentDate();
  
  // Set time of today to midnight for precise calendar D-day calculation
  const todayMidnight = new Date(today.getFullYear(), today.getMonth(), today.getDate());

  ExamList.forEach(exam => {
    const examDate = new Date(exam.date);
    const examMidnight = new Date(examDate.getFullYear(), examDate.getMonth(), examDate.getDate());
    
    // Calculate difference in milliseconds
    const timeDiff = examMidnight.getTime() - todayMidnight.getTime();
    
    // Convert ms difference to days
    const daysLeft = Math.round(timeDiff / (1000 * 60 * 60 * 24));
    
    // Save to object variable
    exam.dDay = daysLeft;

    // Apply status matching the spec pseudocode
    if (exam.dDay <= 3 && exam.dDay >= 0) {
      exam.status = "🚨 임박";
    } else if (exam.dDay < 0) {
      exam.status = "완료";
    } else {
      exam.status = "진행중";
    }
  });
}

// Format Date string for view (e.g. 2026-06-23T14:00 -> 2026.06.23 (화) 14:00)
function formatDateString(dateStr) {
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  
  const week = ["일", "월", "화", "수", "목", "금", "토"];
  const dayName = week[d.getDay()];
  
  const hh = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  
  return `${yyyy}.${mm}.${dd} (${dayName}) ${hh}:${min}`;
}

// 3. UI Component Actions & Toast System
function showToast(message, type = "success") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  const iconName = type === "success" ? "check-circle" : "alert-circle";
  
  toast.innerHTML = `
    <div class="toast-icon">
      <i data-lucide="${iconName}"></i>
    </div>
    <div class="toast-message">${message}</div>
  `;
  
  container.appendChild(toast);
  lucide.createIcons();
  
  // Slide out after 3 seconds, then remove
  setTimeout(() => {
    toast.classList.add("removing");
    toast.addEventListener("animationend", () => {
      toast.remove();
    });
  }, 3000);
}

// 4. Form Validation & Subject Registration
function handleAddExam(event) {
  event.preventDefault();
  
  const courseInput = document.getElementById("course-name");
  const dateInput = document.getElementById("exam-datetime");
  const priorityInputs = document.getElementsByName("priority");
  
  const course = courseInput.value.trim();
  const dateVal = dateInput.value; // Format: "YYYY-MM-DDTHH:MM"
  
  let priority = "상";
  for (const radio of priorityInputs) {
    if (radio.checked) {
      priority = radio.value;
      break;
    }
  }
  
  // Date validations
  const now = getCurrentDate();
  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  
  // Exception handling (if statements)
  if (!course) {
    showToast("과목명을 입력해 주세요.", "error");
    courseInput.focus();
    return;
  }
  
  if (!dateVal) {
    showToast("시험 날짜와 시간을 선택해 주세요.", "error");
    dateInput.focus();
    return;
  }
  
  const selectedDate = new Date(dateVal);
  const selectedMidnight = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate());
  
  // Check if date is in the past (before today)
  if (selectedMidnight < todayMidnight) {
    showToast("오늘 이전의 날짜는 등록할 수 없습니다.", "error");
    dateInput.focus();
    return;
  }
  
  // Create new exam item
  const newExam = {
    id: "exam-" + Date.now(),
    course: course,
    date: dateVal,
    priority: priority
  };
  
  // Add to ExamList array
  ExamList.push(newExam);
  
  // Save, Recalculate, and Render
  saveExams();
  refreshDashboard();
  
  // Reset Form
  courseInput.value = "";
  dateInput.value = "";
  document.querySelector('.priority-option.option-high input').checked = true;
  
  showToast(`'${course}' 과목 일정을 성공적으로 등록했습니다!`);
}

// Delete Exam
function handleDeleteExam(id) {
  const index = ExamList.findIndex(exam => exam.id === id);
  if (index !== -1) {
    const courseName = ExamList[index].course;
    ExamList.splice(index, 1);
    saveExams();
    refreshDashboard();
    showToast(`'${courseName}' 시험 일정이 삭제되었습니다.`, "success");
  }
}

// 5. Sorting, Filtering and Dashboard Render Logic
let currentTab = "all";
let currentSearch = "";
let currentSort = "dday-asc";

// Get Priority Value for sorting weight
function getPriorityWeight(priority) {
  switch (priority) {
    case "상": return 3;
    case "중": return 2;
    case "하": return 1;
    default: return 0;
  }
}

function refreshDashboard() {
  // Always update D-Days first
  calculateAllDDays();
  
  // Update overall statistics
  updateStats();
  
  // Filter list
  let filtered = [...ExamList];
  
  // Search Filter
  if (currentSearch) {
    const query = currentSearch.toLowerCase();
    filtered = filtered.filter(exam => exam.course.toLowerCase().includes(query));
  }
  
  // Tab Status Filter
  if (currentTab === "active") {
    filtered = filtered.filter(exam => exam.dDay > 3);
  } else if (currentTab === "impending") {
    filtered = filtered.filter(exam => exam.dDay <= 3 && exam.dDay >= 0);
  } else if (currentTab === "completed") {
    filtered = filtered.filter(exam => exam.dDay < 0);
  }
  
  // Sorting (Ascending / Descending by D-Day, or by Priority)
  filtered.sort((a, b) => {
    if (currentSort === "dday-asc") {
      // Completed exams (dDay < 0) go to the very bottom
      if (a.dDay < 0 && b.dDay >= 0) return 1;
      if (a.dDay >= 0 && b.dDay < 0) return -1;
      // Otherwise sort by nearest D-Day first
      return a.dDay - b.dDay;
    } else if (currentSort === "dday-desc") {
      // Completed exams go to bottom
      if (a.dDay < 0 && b.dDay >= 0) return 1;
      if (a.dDay >= 0 && b.dDay < 0) return -1;
      return b.dDay - a.dDay;
    } else if (currentSort === "priority-desc") {
      // Primary sort by priority weight descending
      const weightDiff = getPriorityWeight(b.priority) - getPriorityWeight(a.priority);
      if (weightDiff !== 0) return weightDiff;
      // Secondary sort: nearest D-Day first (ignoring completed bottom rule for purity)
      return a.dDay - b.dDay;
    }
    return 0;
  });
  
  // Render cards
  const container = document.getElementById("exam-list-container");
  const emptyState = document.getElementById("empty-state");
  
  container.innerHTML = "";
  
  if (filtered.length === 0) {
    emptyState.style.display = "flex";
  } else {
    emptyState.style.display = "none";
    
    // Render sorted list using loop
    filtered.forEach(exam => {
      const card = document.createElement("div");
      
      // Determine CSS status class
      let statusClass = "status-active";
      let ddayText = "";
      
      if (exam.dDay === 0) {
        statusClass = "status-impending";
        ddayText = "D-Day";
      } else if (exam.dDay > 0) {
        statusClass = exam.dDay <= 3 ? "status-impending" : "status-active";
        ddayText = `D-${exam.dDay}`;
      } else {
        statusClass = "status-completed";
        ddayText = "종료됨";
      }
      
      card.className = `exam-card ${statusClass}`;
      
      // Priority label class helper
      let priorityClass = "badge-priority-low";
      if (exam.priority === "상") priorityClass = "badge-priority-high";
      if (exam.priority === "중") priorityClass = "badge-priority-medium";
      
      // Display subtexts for D-Day
      let displayDdayLabel = "";
      if (exam.dDay === 0) {
        displayDdayLabel = "오늘 시험";
      } else if (exam.dDay > 0) {
        displayDdayLabel = `${exam.dDay}일 남음`;
      } else {
        displayDdayLabel = "종료된 시험";
      }
      
      card.innerHTML = `
        <div class="card-meta">
          <span class="badge-priority ${priorityClass}">
            <span class="dot"></span>중요도 ${exam.priority}
          </span>
          <button class="delete-btn" onclick="handleDeleteExam('${exam.id}')" title="삭제">
            <i data-lucide="trash-2"></i>
          </button>
        </div>
        <div class="card-body">
          <h3 class="course-title" title="${exam.course}">${exam.course}</h3>
          <span class="exam-time">
            <i data-lucide="clock"></i>
            ${formatDateString(exam.date)}
          </span>
        </div>
        <div class="card-dday-area">
          <span class="dday-text">${ddayText}</span>
          <span class="dday-status-badge">${exam.status}</span>
        </div>
      `;
      
      container.appendChild(card);
    });
    
    // Hydrate icons
    lucide.createIcons();
  }
}

// Update Dashboard Statistics Card Numbers
function updateStats() {
  const total = ExamList.length;
  const impending = ExamList.filter(e => e.dDay <= 3 && e.dDay >= 0).length;
  const completed = ExamList.filter(e => e.dDay < 0).length;
  
  document.getElementById("total-count").textContent = total;
  document.getElementById("impending-count").textContent = impending;
  document.getElementById("completed-count").textContent = completed;
}

// 6. Real-Time Closest Exam Timer Widget
function updateNextExamTicker() {
  const now = new Date();
  const tickerElement = document.getElementById("next-exam-ticker");
  const tickerCard = document.getElementById("ticker-card");
  
  // Find all future/active exams (date is in the future)
  const activeExams = ExamList.filter(exam => new Date(exam.date).getTime() > now.getTime());
  
  if (activeExams.length === 0) {
    tickerElement.textContent = "진행 예정인 시험이 없습니다";
    tickerCard.classList.remove("active-alert");
    return;
  }
  
  // Sort to find the absolute closest one
  activeExams.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const nextExam = activeExams[0];
  
  const diffMs = new Date(nextExam.date).getTime() - now.getTime();
  
  // Calculate days, hours, minutes, seconds
  const secs = Math.floor(diffMs / 1000) % 60;
  const mins = Math.floor(diffMs / (1000 * 60)) % 60;
  const hours = Math.floor(diffMs / (1000 * 60 * 60)) % 24;
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  
  // Format numbers
  const dStr = days > 0 ? `${days}일 ` : "";
  const hStr = String(hours).padStart(2, '0');
  const mStr = String(mins).padStart(2, '0');
  const sStr = String(secs).padStart(2, '0');
  
  tickerElement.innerHTML = `<strong>${nextExam.course}</strong>까지 <span class="countdown-digits">${dStr}${hStr}:${mStr}:${sStr}</span>`;
  
  // If exam is impending (<=3 days), make ticker glow red
  const nextExamDateClean = new Date(nextExam.date);
  const nextExamMidnight = new Date(nextExamDateClean.getFullYear(), nextExamDateClean.getMonth(), nextExamDateClean.getDate());
  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const dayDiff = Math.round((nextExamMidnight.getTime() - todayMidnight.getTime()) / (1000 * 60 * 60 * 24));
  
  if (dayDiff <= 3 && dayDiff >= 0) {
    tickerCard.classList.add("active-alert");
  } else {
    tickerCard.classList.remove("active-alert");
  }
}

// 7. Event Binding & Initialization
document.addEventListener("DOMContentLoaded", () => {
  // Load local storage
  loadExams();
  
  // Bind form submission
  const form = document.getElementById("exam-form");
  if (form) {
    form.addEventListener("submit", handleAddExam);
  }
  
  // Bind search box
  const searchInput = document.getElementById("search-input");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      currentSearch = e.target.value;
      refreshDashboard();
    });
  }
  
  // Bind sort select
  const sortSelect = document.getElementById("sort-select");
  if (sortSelect) {
    sortSelect.addEventListener("change", (e) => {
      currentSort = e.target.value;
      refreshDashboard();
    });
  }
  
  // Bind tabs
  const tabBtns = document.querySelectorAll(".tab-btn");
  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      tabBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentTab = btn.dataset.tab;
      refreshDashboard();
    });
  });
  
  // Perform initial render
  refreshDashboard();
  
  // Start real-time ticking
  updateNextExamTicker();
  setInterval(updateNextExamTicker, 1000);
});

// Bind delete exam globally so onclick can reach it
window.handleDeleteExam = handleDeleteExam;
