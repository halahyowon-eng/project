# 기말고사 디데이 커넥터 (Final Exam D-Day Tracker)

기말고사 과목과 시험 일정을 등록하고 남은 D-Day를 실시간으로 계산하여 중요도 및 시험 일정 순으로 정렬/시각화해 주는 웹 서비스입니다. 
글래스모피즘(Glassmorphism) 기반의 수려한 다크 테마 디자인과 직관적인 실시간 타이머를 제공합니다.

## 주요 기능
1. **시험 일정 및 과목 등록**: 과목명, 시험 날짜/시간, 중요도(상/중/하)를 등록합니다. 과거 날짜나 빈 이름은 유효성 검사로 자동 차단됩니다.
2. **실시간 D-Day 연산**: 밀리초(ms) 단위 차이를 환산해 당일 시험(`D-Day`), 남은 시험(`D-N`), 완료된 시험(`종료됨`)으로 구분합니다.
3. **🚨 임박 표시**: D-3일 이내로 다가온 시험은 빨간색 테두리와 백그라운드로 강렬히 강조됩니다.
4. **실시간 카운트다운 타이커**: 가장 가까운 미래 시험까지 남은 날짜, 시간, 분, 초를 매 초마다 실시간으로 리프레시하여 보여줍니다.
5. **정렬 및 검색 필터**: 과목명 실시간 필터링, 정렬 필터(시험일 순, 중요도 순) 및 탭별 필터(진행중, 임박, 완료)를 제공합니다.
6. **로컬 데이터 보존**: 등록된 시험 정보가 브라우저의 `localStorage`에 자동 저장되어 페이지를 새로고침해도 유지됩니다.

---

## 🚀 로컬에서 실행하기

별도의 설치나 빌드 과정 없이 정적 파일로 바로 구동할 수 있습니다.

### 방법 1: 파일 바로 열기
1. [index.html](index.html) 파일을 마우스 더블클릭하여 브라우저에서 실행합니다.

### 방법 2: 로컬 웹 서버 구동
명령어 창(Terminal)에서 아래 명령어를 실행하여 웹 서버를 띄워 접속할 수 있습니다.
* **Node.js**: `npx http-server -p 3000` (이후 브라우저에서 `http://localhost:3000` 접속)
* **Python**: `python -m http.server 3000` (이후 브라우저에서 `http://localhost:3000` 접속)

---

## 🐙 GitHub에 올려 Public으로 만들고 임포트하는 방법

이 코드를 본인의 GitHub 저장소에 업로드하고 공유하는 방법입니다.

### 방법 1: GitHub CLI를 사용하여 터미널에서 즉시 생성 (권장 - 가장 빠름)
로컬에 GitHub CLI(`gh`)가 설치되어 있다면 아래 한 줄의 명령어로 즉시 퍼블릭 리포지토리를 만들고 코드를 푸시할 수 있습니다.
```bash
git init
git add .
git commit -m "Initialize Final Exam D-Day Tracker"
gh repo create final-exam-dday-counter --public --source=. --remote=origin --push
```

### 방법 2: GitHub 웹사이트를 통한 업로드
1. GitHub 로그인 후 **[New Repository 생성 페이지](https://github.com/new)** 로 이동합니다.
2. Repository name에 `final-exam-dday-counter`를 입력하고, **Public**으로 설정한 후 `Create repository`를 누릅니다.
3. 생성된 리포지토리 페이지에서 원격 URL(예: `https://github.com/username/final-exam-dday-counter.git`)을 복사한 뒤, 이 프로젝트 폴더 터미널에서 아래 명령을 실행합니다:
   ```bash
   git init
   git branch -M main
   git add .
   git commit -m "Initial commit"
   git remote add origin [복사한_깃허브_리포지토리_주소]
   git push -u origin main
   ```
4. 완료되면 본인의 GitHub 주소 `https://github.com/본인ID/final-exam-dday-counter`가 Public 코드가 됩니다.
